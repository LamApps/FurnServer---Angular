import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-dashboard-edit',
  templateUrl: './dashboard-edit.component.html',
  styleUrls: ['./dashboard-edit.component.scss']
})
export class DashboardEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
