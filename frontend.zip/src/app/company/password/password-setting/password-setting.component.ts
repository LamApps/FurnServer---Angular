import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-password-setting',
  templateUrl: './password-setting.component.html',
  styleUrls: ['./password-setting.component.scss']
})
export class PasswordSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
