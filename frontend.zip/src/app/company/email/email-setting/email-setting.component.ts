import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-email-setting',
  templateUrl: './email-setting.component.html',
  styleUrls: ['./email-setting.component.scss']
})
export class EmailSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
