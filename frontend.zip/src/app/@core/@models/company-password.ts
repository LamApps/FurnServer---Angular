export class CompanyPassword {
    id: number;
    pwd: string;
    description: Date;
    has_threshold: boolean;
    threshold: number;
    password: number;
    company: number;
}