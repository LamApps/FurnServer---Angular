export class Company {
    id: string;
    app_id: string;
    name: string;
    expire_date: Date;
    menu_password: string;
    first_time_status: boolean;
    active: boolean;
}