export class Roles {
    id: string;
    name: string;
    code: string;
    description: string;
}