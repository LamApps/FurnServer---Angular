export class Password {
    id: string;
    name: string;
    code: string;
    description: Date;
}