import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-utils',
  templateUrl: './utils.component.html',
  styleUrls: ['./utils.component.scss']
})
export class UtilsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
